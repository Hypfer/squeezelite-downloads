To add mp3 playback support, install either libmad-0.dll or libmpg123-0.dll in the same directory as this file

Suggested source:
1) download http://www.mpg123.de/download/win32/mpg123-1.14.4-x86.zip from MPG123
2) extract mpg123-1.14.4-x86/libmpg123-0.dll into this directory (the file is approx ~282k when extracted)
